#include "topsis.h"
#include <QTextCodec>
#include <QDebug>
#include <qmath.h>

/**
 * @brief TOPSIS::TOPSIS
 */

TOPSIS::TOPSIS()
{

}

TOPSIS::~TOPSIS()
{


}
/**
 * @brief TOPSIS::SetEvaluateData
 * @param scenceNames
 * @param indexInfos
 * @param data
 */
QMap<QString,double> TOPSIS::GetEvaluateResult(QStringList scenceNames, QVector<bool> indexs, QVector<double> data)
{
    int nRow     =  scenceNames.count ();
    int nColumn  =  indexs.count ();
    /*************************************************
     * 1  一维->二维 转换
     *************************************************/
    double** arrayData = new double*[nRow];
    for(int j=0;j<nRow;j++)
    {
        arrayData[j] = new double[nColumn];   //这个指针数组的每个指针元素又指向一个数组。
    }
    for (int i=0;i<nRow;i++)
    {
        for (int j=0;j<nColumn;j++)
        {
            double dataValue = data.at (i * nRow + j);
            arrayData[i][j]  = dataValue;
        }
    }

    /*************************************************
     * 2  低优指标  ->   高优指标
     *    绝对数低优指标100/X,相对数低优指标1-X
     *************************************************/
    int iRow = 0;
    foreach (bool index, indexs)
    {
        if(index == false)
        {
            if(arrayData[0][iRow] > 0 && arrayData[0][iRow]<1)
            {
                for (int j=0;j<nRow;j++)
                {
                    double dataValue  = arrayData[j][iRow];
                    arrayData[j][iRow] = 1-dataValue;
                }
            }
            else
            {
                for (int j=0;j<nRow;j++)
                {
                    double dataValue  = arrayData[j][iRow];
                    arrayData[j][iRow] = 100.0/dataValue;
                }
            }
        }
        iRow++;
    }
    /*************************************************
     * 3  归一化数据
     *************************************************/
    double** arrayDataCopy = new double*[nRow];
    for(int j=0;j<nRow;j++)
    {
        arrayDataCopy[j] = new double[nColumn];   //这个指针数组的每个指针元素又指向一个数组。
    }

    for (int i=0;i<nRow;i++)
    {
        for (int j=0;j<nColumn;j++)
        {
            double dataValue     =  arrayData[i][j];
            double tmpSum = 0;
            for(int k=0;k<nRow;k++)
            {
                double tmp = arrayData[k][j];
                tmpSum = tmpSum + qPow(tmp,2);
            }
            arrayDataCopy[i][j]  =  dataValue/qSqrt(tmpSum);
        }
    }
    /*************************************************
     * 4   找最优解
     *************************************************/
    double* goodIndex = new double[nColumn];   //这个指针数组的每个指针元素又指向一个数组。
    double* badIndex  = new double[nColumn];   //这个指针数组的每个指针元素又指向一个数组。

    for (int j=0;j<nColumn;j++)
    {
        goodIndex[j]  =  0;
        badIndex[j]    = 1;
        for (int i=0;i<nRow;i++)
        {
             double dataValue     =  arrayDataCopy[i][j];
             if(dataValue > goodIndex[j])
                  goodIndex[j] = dataValue;
             if(dataValue < badIndex[j] )
                  badIndex[j]  = dataValue;
        }
    }

    /*************************************************
     * 5   计算Ci指数
     *************************************************/
    double** results = new double*[nRow];
    for(int i = 0;i<nRow;i++)
    {
        results[i] = new double[3];
    }

    for(int i=0;i<nRow;i++)
    {
        double tmpSum1 = 0;
        double tmpSum2 = 0;
        for (int j=0;j<nColumn;j++)
        {
            double valueTMP1 = arrayDataCopy[i][j] - goodIndex[j];
            double valueTMP2 = arrayDataCopy[i][j] - badIndex[j];
            tmpSum1 = tmpSum1 + qPow(valueTMP1,2);
            tmpSum2 = tmpSum2 + qPow(valueTMP2,2);
        }
        double s1 = qSqrt(tmpSum1);
        double s2 = qSqrt(tmpSum2);
        results[i][0] = s1;
        results[i][1] = s2;
        results[i][2] = s2/(s1+s2)*100;
    }

    /*************************************************
     * 6  返回计算结果
     *************************************************/
    QMap<QString,double>  evaluteRes;

    for(int i=0;i<nRow;i++)
    {
         evaluteRes[scenceNames.at (i)] = results[i][2];
    }

    /*************************************************
     * 7  删除开辟的内存空间
     *************************************************/

    for (int i=0;i<nRow;i++)
    {
        delete[] arrayData[i];    //先撤销指针元素所指向的数组
    }
    delete[] arrayData;

    for (int i=0;i<nRow;i++)
    {
        delete[] arrayDataCopy[i]; //先撤销指针元素所指向的数组
    }
    delete[] arrayDataCopy;

    delete[] goodIndex;
    delete[] badIndex;

    for (int i=0;i<nRow;i++)
    {
        delete[] results[i]; //先撤销指针元素所指向的数组
    }
    delete[] results;

    return evaluteRes;
}










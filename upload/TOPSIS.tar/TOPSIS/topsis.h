#ifndef TOPSIS_H
#define TOPSIS_H
#include <QString>
#include <QStringList>
#include <QVector>
#include <QMap>

/*****************************************************************************
 *
 * TOPSIS Core Code
 *
 * Create  time  2014.9.17
 *
 * Update  time  2004.9.17

 *
 ****************************************************************************/

/**
 * @brief The TOPSIS class
 */
class TOPSIS
{

public:
    /**
     * @brief TOPSIS
     * @param scenceNames
     * @param indexInfos
     */
    TOPSIS();

    ~TOPSIS();

    /**
     * @brief SetEvaluateData
     * @param scenceNames
     * @param indexInfos
     * @param data
     * 2014.9.18
     */
    static  QMap<QString,double> GetEvaluateResult(QStringList scenceNames,
                                                   QVector < bool > indexs,
                                                   QVector < double > data);



private:



};

#endif // TOPSIS_H

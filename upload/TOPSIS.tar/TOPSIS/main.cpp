#include <QCoreApplication>
#include "topsis.h"
#include <QDebug>
#include <QTextCodec>

/*****************************************************************************
 *
 * TOPSIS Test
 *
 * Create  time  2014.9.17
 *
 * Update  time  2004.9.17

 *
 ****************************************************************************/

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    /*************************************************
     * 1 数据准备
     *************************************************/
    QStringList  scencelist;
    scencelist.append ("Historical trend Scenario");
    scencelist.append ("General protection Scenario");
    scencelist.append ("Strict protection Scenario");
    scencelist.append ("General development Scenario");

    QVector< bool > indexList;
    indexList.append (true);
    indexList.append (false);
    indexList.append (false);
    indexList.append (false);

    QVector <double>  data;
    data<<85<<75<<0.2<<80<<80<<55<<0.2<<75<<100<<45<<0.1<<65<<75<<55<<0.3<<75;

    /*************************************************
     * 2  计算过程
     *************************************************/
    QMap <QString, double>  evaluteRes = TOPSIS::GetEvaluateResult (scencelist,indexList,data);


    /*************************************************
     * 3  结果展示
     *************************************************/
    QMap<QString, double>::const_iterator i = evaluteRes.constBegin();
    while (i != evaluteRes.constEnd())
    {
        qDebug() << i.key() << ": " << i.value() << "\n";
        ++i;
    }

    return a.exec();

}

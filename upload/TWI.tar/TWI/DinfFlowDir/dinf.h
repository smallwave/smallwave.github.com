#ifndef DINF_H
#define DINF_H

#include <mpi.h>
#include "..\Common\linearpart.h"
#include "..\Common\createpart.h"
#include "..\Common\commonLib.h"
#include "..\Common\tiffIO.h"
#include <math.h>
#include "Node.h"

int dontCross( int k, int i, int j, tdpartition *flowDir);

int CalAngAndSlope(char* demfile, char* angfile, char *slopefile, char *flowfile, int useflowfile);

int DinfFlowDir(tdpartition * ptrFel,
				tdpartition * ptrAng,
				tdpartition * ptrSlope, 
				char *flowfile = NULL, 
				int useflowfile = false);

void VSLOPE(float E0,float E1, float E2, float D1,float D2,float DD, float *S,float *A);

void SET2(int I, int J,float *DXX,float DD, tdpartition *elevDEM, tdpartition *flowDir, tdpartition *slope);

void SET2(int I, int J,float *DXX,float DD, tdpartition *elevDEM, tdpartition *elev2, tdpartition *flowDir, tdpartition *dn);

long setPosDirDinf(tdpartition *elevDEM, tdpartition *flowDir, tdpartition *slope, int useflowfile);

long resolveflats( tdpartition *elevDEM, tdpartition *flowDir, queue<node> *que, bool &first);

#endif
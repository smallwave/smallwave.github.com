#ifndef FLOOD_H
#define FLOOD_H

#include <mpi.h>
#include <queue>
#include "..\Common\commonLib.h"
#include "..\Common\linearpart.h"
#include "..\Common\createpart.h"
#include "..\Common\tiffIO.h"


int flood( char* demfile, char* felfile, char *fdrfile, int usefdr,bool verbose, 
           bool is_4Point,bool use_mask,char *maskfile);


//short useflowfile=0;
//bool verbose=false;  //  Initialize verbose flag
//bool is_4p = false; // four-point flow method versus eight-point, arb 5/31/11
//char maskfile[MAXLN]; // mask out actual depressions, arb 5/31/11
//bool use_mask = false; // flag to specify the optional mask file, arb 5/31/11


int PitRemove( tiffIO dem, 
		   tdpartition * ptrFel, 
		   bool verbose   = false, 
		   bool is_4Point = false,
		   bool use_mask  = false,
		   char *maskfile = NULL) /* these three added by arb, 5/31/11 */;

#endif
#ifndef TWI_H
#define TWI_H

#include <mpi.h>
#include <math.h>
#include "..\Common\commonLib.h"
#include "..\Common\linearpart.h"
#include "..\Common\createpart.h"
#include "..\Common\tiffIO.h"


int twigrid(char *slopefile,char *areafile,char *twifile, int prow, int pcol);

int TWI(tdpartition * ptrSlope,
		tdpartition* ptrSca,
		tdpartition* ptrTWI,
		int prow = 0, 
		int pcol = 0);


#endif



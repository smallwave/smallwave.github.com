/*  TWImn main program to compute Beven and Kirkby topographic wetness index ln(a/S).

David Tarboton
Utah State University  
March 9, 2014 

*/

/*  Copyright (C) 2014  David Tarboton, Utah State University

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License 
version 2, 1991 as published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

A copy of the full GNU General Public License is included in file 
gpl.html. This is also available at:
http://www.gnu.org/copyleft/gpl.html
or from:
The Free Software Foundation, Inc., 59 Temple Place - Suite 330, 
Boston, MA  02111-1307, USA.

If you wish to use or incorporate this program (or parts of it) into 
other software that does not meet the GNU General Public License 
conditions contact the author to request permission.
David G. Tarboton  
Utah State University 
8200 Old Main Hill 
Logan, UT 84322-8200 
USA 
http://www.engineering.usu.edu/dtarb/ 
email:  dtarb@usu.edu 
*/

//  This software is distributed from http://hydrology.usu.edu/taudem/

#include <time.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include  <fstream>
#include "..\Common\commonLib.h"
#include "..\Common\tardemlib.h"
#include "..\Common\tiffIO.h"
#include "..\PitRemove\flood.h"
#include "..\DinfFlowDir\dinf.h"
#include "..\AreaDinf\areadinf.h"
#include "ArgumentParser.h"
#include <iostream>
#include <vector>
#include "TWI.h"

using namespace std;

/************************************************************************/
/*  TWI һЩ��Ϣ                                                                    */
/************************************************************************/
struct TWIIab
{
	float maxValue;   // ��������ֵ
	float minValue;   // �������Сֵ
	int nColut;       // ���������
};


int main(int argc,char **argv)
{
	/***********************************************************************
	* 1�� ��������˵��
	*
	**********************************************************************/
	// use an ArgumentParser object to manage the program arguments.
	ArgumentParser arguments(&argc,argv);
	ApplicationUsage* usage = arguments.getApplicationUsage();
	usage->setDescription(" This is the Program which calulation TI(Topographic index) and Output txt Info for TOPMODEL.");
	usage->setCommandLineUsage( arguments.getApplicationName() + " [options] filename ..." );
	usage->addCommandLineOption( "-h or --help", "Display this help information." );
	usage->addCommandLineOption( "--input <filename>", "The input source DEM name" );
	usage->addCommandLineOption( "--outputTIF <filename>", "The output TIF name" );
	usage->addCommandLineOption( "--numclass  <int>", "Intput grid class number(Default  10)." );
	usage->addCommandLineOption( "--outputTXT <filename>", "The output TXT name " );

	/***********************************************************************
	* 2�������ж�
	*
	**********************************************************************/
	if ( arguments.read("-h") || arguments.read("--help") )
	{
		usage->write( std::cout );
		return 1;
	}
	// report any errors if they have occurred when parsing the program arguments.
	if (arguments.errors())
	{
		arguments.writeErrorMessages(std::cout);
		return 1;
	}
	// �жϲ�������
	if (arguments.argc()<=0)
	{
		arguments.getApplicationUsage()->write(std::cout,ApplicationUsage::COMMAND_LINE_OPTION);
		return 1;
	}
	/***********************************************************************
	* 3����������
	*
	**********************************************************************/
	std::string demfile;
	bool outputtwiTIF  = false;
	std::string twitiffile;
	bool outputtwiTXT  = true;
	int  numberClass   = 10;
	std::string twitxtfile;
	
	//demfile
	if(argc>1)  //argv[1]����
	{
		demfile =  argv[1];
	}
	int indexInput = arguments.find ("--input");
	if(indexInput > 0)
	{
		while ( arguments.read("--input",demfile) ) {}
	}
	//twitiffile
	int indexOutputTIF = arguments.find ("--outputTIF");
	if(indexOutputTIF > 0)
	{
		while ( arguments.read("--outputTIF",twitiffile) ) {}
		outputtwiTIF = true;
	}

	//twitxtfile
	while ( arguments.read("--numclass",numberClass) ) {}
	int indexOutputTXT = arguments.find ("--outputTXT");
	if(indexOutputTXT > 0)
	{
		while ( arguments.read("--outputTXT",twitxtfile) ) {}
	}
	else
	{
		int nindex = demfile.find_last_of("\\");
		twitxtfile = demfile.substr(0,nindex) + "\\TI.txt";
	}


	/************************************************************************/
	/* ��ʼ����  64bit                                                                     */
	/************************************************************************/
	MPI_Init(NULL,NULL);
	{
		//Only used for timing
		int rank,size;
		MPI_Comm_rank(MCW,&rank);
		MPI_Comm_size(MCW,&size);
		if(rank==0)printf("Topographic Wetness Index version %s\n",TDVERSION);

		tiffIO dem(const_cast<char*>(demfile.c_str()),FLOAT_TYPE);
		long totalX = dem.getTotalX();
		long totalY = dem.getTotalY();
		double dx = dem.getdx();
		double dy = dem.getdy();
		float felNodata       = -3.0e38;
		float slopeNodata     = -1.0f;
		tdpartition*ptrFel    = CreateNewPartition(FLOAT_TYPE, totalX, totalY, dx, dy, felNodata);
		tdpartition* ptrAng   = CreateNewPartition(FLOAT_TYPE, totalX, totalY, dx, dy, MISSINGFLOAT);
		tdpartition* ptrSlope = CreateNewPartition(FLOAT_TYPE, totalX, totalY, dx, dy, slopeNodata);
		tdpartition* ptrSca   = CreateNewPartition(FLOAT_TYPE, totalX, totalY, dx, dy, -1.0f);
		tdpartition* ptrTWI   = CreateNewPartition(FLOAT_TYPE, totalX, totalY, dx, dy, -1.0f);
		/************************************************************************/
		/* ��һ��  Pit Remove                                                                     */
		/************************************************************************/
	    printf("/************************************************************************/\n");
		printf("/*    First step :  calculate fill of  dem data \n");
		printf("/************************************************************************/\n");
		PitRemove(dem,ptrFel);

		/************************************************************************/
		/* �ڶ���  DinfFlowDir                                                                  */
		/************************************************************************/
	    printf("/************************************************************************/\n");
		printf("/*    Second step :  calculate slope and angle  of  fill data \n");
		printf("/************************************************************************/\n");
		DinfFlowDir(ptrFel,ptrAng,ptrSlope);

		/************************************************************************/
		/* ������  AreaDinf                                                               */
		/************************************************************************/
		printf("/************************************************************************/\n");
		printf("/*    Third step :  calculate catchment area  of  angle data \n");
		printf("/************************************************************************/\n");
		AreaDinf(ptrAng,ptrSca);

		/************************************************************************/
		/* ���Ĳ�  AreaDinf                                                               */
		/************************************************************************/
		printf("/************************************************************************/\n");
		printf("/*    Fourth step :  calculate twi  of  slope data and area data \n");
		printf("/************************************************************************/\n");
		TWI(ptrSlope,ptrSca,ptrTWI);

		/************************************************************************/
		/* ���岽  Output TWI.tif
		/************************************************************************/
		printf("/************************************************************************/\n");
		printf("/*   Output  file  \n");
		printf("/************************************************************************/\n");
		int nx = ptrTWI->getnx();
		int ny = ptrTWI->getny();
		if (outputtwiTIF)
		{
			//Create and write TIFF file
			int xstart, ystart;
			ptrTWI->localToGlobal(0, 0, xstart, ystart);

			float aNodata = -1.0f;
			tiffIO twi(const_cast<char*>(twitiffile.c_str()), FLOAT_TYPE, &aNodata, dem);
			twi.write(xstart, ystart, ny, nx, ptrTWI->getGridPointer());
			printf("Output TIF file   %s \n",twitiffile.c_str());
		}
		/************************************************************************/
		/* ������  Output TWI.txt
		/************************************************************************/
		if (outputtwiTXT)
		{
			//���ı�
			ofstream txtfile(twitxtfile.c_str());
			if (!txtfile)
			{
				return 0;
			}
			long i,j;
			float tempTWI = 0;
			float maxTWI  = 0;
			float minTWI  = 1000;
			/************************************************************************/
			/* ���������Сֵ                                                                     */
			/************************************************************************/
			for(j=0; j<ny; j++) 
			{
				for(i=0; i<nx; i++ )
				{
					if(!ptrTWI->isNodata(i,j))
					{
						ptrTWI->getData(i,j,tempTWI);
						maxTWI = tempTWI > maxTWI ? tempTWI:maxTWI;
						minTWI = tempTWI < minTWI ? tempTWI:minTWI;
					}
				}
			}
			txtfile<<0<<" "<<maxTWI<<"\n";
			/************************************************************************/
			/* ����                                                                     */
			/************************************************************************/
			float tmp = maxTWI - minTWI;
			float tmpincrement = tmp/numberClass;
			float maxTmp = maxTWI;
			vector<TWIIab*> vecTWITab;
			for (int i = 0;i<numberClass;i++)
			{
				TWIIab* twiTab   = new TWIIab();
				twiTab->maxValue = maxTmp;
				twiTab->minValue = twiTab->maxValue-tmpincrement;
				twiTab->nColut   = 0;
				maxTmp -= tmpincrement;
				vecTWITab.push_back(twiTab);
			}

			/************************************************************************/
			/*  calulation count                                                                     */
			/************************************************************************/
			float nDataCount = 0;
			for(j=0; j<ny; j++) 
			{
				for(i=0; i<nx; i++ )
				{
					if(!ptrTWI->isNodata(i,j))
					{
						nDataCount++;
						ptrTWI->getData(i,j,tempTWI);
						for (int k = 0;k<numberClass;k++)
						{
							TWIIab* twiTab = vecTWITab.at(k);
							if (twiTab->minValue<tempTWI && tempTWI < twiTab->maxValue)
							{
								twiTab->nColut ++;
							}
						}
					}
				}
			}

			/************************************************************************/
			/*  output txt                                                                   */
			/************************************************************************/
			for (int i = 0;i<numberClass;i++)
			{
				TWIIab* twiTab = vecTWITab.at(i);
				txtfile<<twiTab->nColut/nDataCount<<" "<<twiTab->minValue<<"\n";
			}
			txtfile.close();
			printf("Output TXT file  %s\n",twitxtfile.c_str());


			/************************************************************************/
			/*  delete                                                                   */
			/************************************************************************/
			for (int i = 0;i<numberClass;i++)
			{
				TWIIab* twiTab = vecTWITab.at(i);
				if (twiTab!=NULL)
				{
					delete twiTab;
					twiTab = NULL;
				}
			}
			vecTWITab.clear();

			if (ptrFel!=NULL)
			{
				delete ptrFel;
				ptrFel = NULL;
			}

			if (ptrAng!=NULL)
			{
				delete ptrAng;
				ptrAng = NULL;
			}

			if (ptrSlope!=NULL)
			{
				delete ptrSlope;
				ptrSlope = NULL;
			}

			if (ptrSca!=NULL)
			{
				delete ptrSca;
				ptrSca = NULL;
			}

			if (ptrTWI!=NULL)
			{
				delete ptrTWI;
				ptrTWI = NULL;
			}
		}
	}
	/************************************************************************/
	/* �������� 64bit                                                                     */
	/************************************************************************/
	MPI_Finalize();

	return 0;

}

#include <math.h>
#include <queue>
#include "..\Common\commonLib.h"
#include "..\Common\linearpart.h"
#include "..\Common\createpart.h"
#include "..\Common\tiffIO.h"
#include "..\Common\initneighbor.h"


int area( char* angfile, char* scafile, char *shfile, char *wfile, int useOutlets, int usew, int contcheck);

int AreaDinf(tdpartition* ptrAng,
			 tdpartition* ptrSca, 
			 char *shfile = NULL, 
			 char *wfile = NULL, 
			 int useOutlets = 0, 
			 int usew = 0, 
			 int contcheck = 1);
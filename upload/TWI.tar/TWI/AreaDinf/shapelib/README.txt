These files from Shapelib version 1.3.0 retrieved from
http://download.osgeo.org/shapelib/
1/25/14